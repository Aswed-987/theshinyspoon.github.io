// script.js - small interactions
document.getElementById('year').textContent = new Date().getFullYear();

function toggleMenu(){
  const nav = document.querySelector('.nav');
  if(!nav) return;
  if(getComputedStyle(nav).display === 'none' || nav.style.display === 'none'){
    nav.style.display = 'flex';
  } else {
    nav.style.display = 'none';
  }
}

// Handle success redirect message from formsubmit
document.addEventListener('DOMContentLoaded', function(){
  const params = new URLSearchParams(window.location.search);
  if(params.get('success') === '1'){
    const msg = document.createElement('div');
    msg.className = 'form-success';
    msg.textContent = 'Thanks — your order has been received. We will contact you on WhatsApp shortly.';
    document.body.prepend(msg);
    setTimeout(()=> msg.remove(), 8000);
  }
});
