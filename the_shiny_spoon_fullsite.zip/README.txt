THE SHINY SPOON — Complete website (multi-page) ready for GitHub Pages
Files included in this ZIP:
- index.html
- menu.html
- order.html
- pay.html
- about.html
- contact.html
- styles.css
- script.js
- assets/ (logo.png, hero.jpg, qr.png, gallery images, favicon.png, menu.pdf)

What I built:
- Multi-page responsive website styled with a gold-on-dark theme matching your logo.
- Serverless order form integrated via FormSubmit.co (sends to theshinyspoon2025@gmail.com).
- UPI payment section with QR image and instructions (UPI ID: mdiftekharhussain4019@okicici).
- Google Maps embed for your address.
- WhatsApp quick-order button.

How to deploy on GitHub Pages:
1. Create a GitHub account (if you don't have one) and a new repository named exactly: theshinyspoon.github.io
2. Upload all files from this ZIP into the repository root (you can drag-drop in GitHub web UI).
3. Wait ~1–5 minutes and visit: https://theshinyspoon.github.io
4. To use your own domain later (like theshinyspoon.in), add the domain in repository Settings > Pages and update DNS records with your domain provider.

Notes & customization:
- Replace files in assets/ with your real images:
  - assets/logo.png (your gold logo)
  - assets/hero.jpg (hero image)
  - assets/qr.png (your QR code image)
  - assets/menu.pdf (optional downloadable menu PDF)
  - gallery images as desired
- If you prefer Formspree instead of FormSubmit.co, replace the form 'action' URL in order.html with your Formspree endpoint.
- For advanced backend (order management, SMS/WhatsApp automation), I can help set up a paid server or workflow.

If you want, I can:
- Upload these files to your GitHub repository for you (you'll need to share GitHub access or an invite).
- Replace the placeholder images with the real images you upload here.
- Set up a custom domain and DNS records.

Enjoy! — Aswed
